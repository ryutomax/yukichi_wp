<a href="https://servmask.com/products/google-drive-extension" target="_blank"><?php _e( 'Google Drive', AI1WM_PLUGIN_NAME ); ?></a>
